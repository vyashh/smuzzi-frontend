import { Text, View } from "react-native";

const SignUpPage = () => {
  return (
    <View>
      <Text>Sign up</Text>
    </View>
  );
};

export default SignUpPage;
