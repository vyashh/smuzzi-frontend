import React, { useEffect } from "react";
import { View, Text } from "react-native";
import * as Reanimated from "react-native-reanimated";

const ReanimatedDiag = () => {
  useEffect(() => {
    console.log("Reanimated version:", Reanimated?.version);
    console.log(
      "Has useAnimatedGestureHandler?",
      typeof Reanimated.useAnimatedGestureHandler
    );
  }, []);
  return (
    <View>
      <Text>Check Metro logs</Text>
    </View>
  );
};
export default ReanimatedDiag;
